local addonName = ...
local SND = _G[addonName]

SND.roster = {
  lastScan = 0,
}

local function getNumGuildMembers()
  if GetNumGuildMembers then
    return GetNumGuildMembers()
  end
  return 0
end

local function refreshGuildRoster(self)
  if type(GuildRoster) == "function" then
    self:DebugLog("Roster refresh API: GuildRoster()", true)
    GuildRoster()
    return true
  end

  if type(C_GuildInfo) == "table" and type(C_GuildInfo.GuildRoster) == "function" then
    self:DebugLog("Roster refresh API: C_GuildInfo.GuildRoster()", true)
    C_GuildInfo.GuildRoster()
    return true
  end

  self:DebugLog("Roster refresh unavailable: no GuildRoster API found", true)
  return false
end

function SND:InitRoster()
  self:DebugLog(string.format(
    "Roster init API probe: GuildRoster=%s C_GuildInfo=%s C_GuildInfo.GuildRoster=%s",
    tostring(type(GuildRoster) == "function"),
    tostring(type(C_GuildInfo) == "table"),
    tostring(type(C_GuildInfo and C_GuildInfo.GuildRoster) == "function")
  ), true)
  if self.RegisterBucketEvent then
    self:RegisterBucketEvent("GUILD_ROSTER_UPDATE", 1.0, function()
      self:ScanGuildRoster()
    end)
  else
    self:RegisterEvent("GUILD_ROSTER_UPDATE", function(selfRef)
      selfRef:ScanGuildRoster()
    end)
  end
  if IsInGuild() then
    refreshGuildRoster(self)
  end
end

function SND:ScanGuildRoster()
  if not IsInGuild() then
    if type(self.UpdateGuildMemberCache) == "function" then
      self:UpdateGuildMemberCache({})
    end
    return
  end

  local numMembers = getNumGuildMembers()
  local memberSet = {}
  for index = 1, numMembers do
    local name, rankName, rankIndex, _, _, _, _, _, online, _, classFilename = GetGuildRosterInfo(index)
    if name then
      local nameOnly = strsplit("-", name)
      local playerKey = self:GetPlayerKey(nameOnly)
      local entry = self.db.players[playerKey] or {}
      entry.class = classFilename
      entry.guildRankIndex = rankIndex
      entry.lastSeen = self:Now()
      entry.online = online and true or false
      entry.sharedMats = entry.sharedMats or nil
      self.db.players[playerKey] = entry
      memberSet[nameOnly] = true
    end
  end

  if type(self.UpdateGuildMemberCache) == "function" then
    self:UpdateGuildMemberCache(memberSet)
  end

  self.roster.lastScan = self:Now()
end
