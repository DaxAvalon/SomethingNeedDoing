local addonName = ...
local SND = _G[addonName]

local AceConfig = LibStub("AceConfig-3.0", true)
local AceConfigDialog = LibStub("AceConfigDialog-3.0", true)
local AceConfigRegistry = LibStub("AceConfigRegistry-3.0", true)
local AceDBOptions = LibStub("AceDBOptions-3.0", true)

local function T(key, ...)
  if SND and SND.Tr then
    return SND:Tr(key, ...)
  end
  if select("#", ...) > 0 then
    return string.format(key, ...)
  end
  return key
end

local OPTIONS_APP_NAME = addonName

local function getConfig(self)
  self.db = self.db or {}
  self.db.config = self.db.config or {}
  return self.db.config
end

function SND:GetOptionsTable()
  local dbOptions = nil
  if AceDBOptions and self.dbRoot then
    dbOptions = AceDBOptions:GetOptionsTable(self.dbRoot)
    dbOptions.order = 99
  end

  return {
    type = "group",
    name = T("Something Need Doing"),
    args = {
      general = {
        type = "group",
        name = T("General"),
        order = 1,
        args = {
          showMinimapButton = {
            type = "toggle",
            name = T("Show minimap button"),
            order = 1,
            get = function()
              return getConfig(self).showMinimapButton and true or false
            end,
            set = function(_, value)
              getConfig(self).showMinimapButton = value and true or false
              if type(self.UpdateMinimapButtonVisibility) == "function" then
                self:UpdateMinimapButtonVisibility()
              end
            end,
          },
          debugMode = {
            type = "toggle",
            name = T("Enable debug mode"),
            order = 2,
            get = function()
              return getConfig(self).debugMode and true or false
            end,
            set = function(_, value)
              getConfig(self).debugMode = value and true or false
            end,
          },
          autoPublishOnLogin = {
            type = "toggle",
            name = T("Auto publish on login"),
            order = 10,
            get = function()
              return getConfig(self).autoPublishOnLogin and true or false
            end,
            set = function(_, value)
              getConfig(self).autoPublishOnLogin = value and true or false
            end,
          },
          autoPublishOnLearn = {
            type = "toggle",
            name = T("Auto publish on profession changes"),
            order = 11,
            get = function()
              return getConfig(self).autoPublishOnLearn and true or false
            end,
            set = function(_, value)
              getConfig(self).autoPublishOnLearn = value and true or false
            end,
          },
          shareMatsOptIn = {
            type = "toggle",
            name = T("Share available crafting materials"),
            order = 20,
            get = function()
              return getConfig(self).shareMatsOptIn and true or false
            end,
            set = function(_, value)
              getConfig(self).shareMatsOptIn = value and true or false
            end,
          },
          autoPublishMats = {
            type = "toggle",
            name = T("Auto publish materials"),
            order = 21,
            get = function()
              return getConfig(self).autoPublishMats and true or false
            end,
            set = function(_, value)
              getConfig(self).autoPublishMats = value and true or false
            end,
          },
          officerRankIndex = {
            type = "range",
            name = T("Officer rank index threshold"),
            order = 30,
            min = 0,
            max = 10,
            step = 1,
            get = function()
              return tonumber(getConfig(self).officerRankIndex) or 1
            end,
            set = function(_, value)
              getConfig(self).officerRankIndex = math.floor(tonumber(value) or 1)
            end,
          },
          openMain = {
            type = "execute",
            name = T("Open main window"),
            order = 90,
            func = function()
              self:ToggleMainWindow()
            end,
          },
          resetDb = {
            type = "execute",
            name = T("Reset addon data"),
            order = 91,
            confirm = true,
            confirmText = T("This clears local SND data. Continue?"),
            func = function()
              self:ResetDB()
              if type(self.RefreshAllTabs) == "function" then
                self:RefreshAllTabs()
              end
            end,
          },
        },
      },
      profiles = dbOptions,
    },
  }
end

function SND:InitOptions()
  if self._optionsInitialized then
    return
  end
  self._optionsInitialized = true
  if not (AceConfig and AceConfigDialog) then
    return
  end

  AceConfig:RegisterOptionsTable(OPTIONS_APP_NAME, function()
    return self:GetOptionsTable()
  end)
  self.optionsCategoryId = AceConfigDialog:AddToBlizOptions(OPTIONS_APP_NAME, T("Something Need Doing"))
end

function SND:OpenOptions()
  if AceConfigDialog then
    AceConfigDialog:Open(OPTIONS_APP_NAME)
  end
end

function SND:RefreshOptions()
  if AceConfigRegistry then
    AceConfigRegistry:NotifyChange(OPTIONS_APP_NAME)
  end
end
