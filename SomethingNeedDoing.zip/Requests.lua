local addonName = ...
local SND = _G[addonName]

SND.requests = {}

local STATUS_OPEN = "OPEN"
local STATUS_CLAIMED = "CLAIMED"
local STATUS_CRAFTED = "CRAFTED"
local STATUS_DELIVERED = "DELIVERED"
local STATUS_CANCELLED = "CANCELLED"

local function buildRequestId(requesterGuid)
  local now = SND:Now()
  local nonce = math.random(100000, 999999)
  local playerKey = SND:GetPlayerKey(UnitName("player")) or "unknown"
  local guildKey = (SND.db and SND.db.guildKey) or "noguild"
  local seed = string.format("%s|%s|%s|%d|%d", guildKey, playerKey, requesterGuid or "unknown", now, nonce)
  return string.format("req-%s", SND:HashString(seed))
end

local function applyRequestMeta(self, request, now)
  request.id = request.id or nil
  request.entityType = "REQUEST"
  request.version = tonumber(request.version) or 1
  request.updatedBy = request.updatedBy or self:GetPlayerKey(UnitName("player"))
  request.updatedAtServer = tonumber(request.updatedAtServer) or now
  request.updatedAt = request.updatedAtServer
  if request.deletedAtServer ~= nil then
    request.deletedAtServer = tonumber(request.deletedAtServer)
  end
end

function SND:InitRequests()
  self:RegisterEvent("PLAYER_LOGIN", function(selfRef)
    selfRef:EnsureRequestsTable()
  end)
end

function SND:EnsureRequestsTable()
  if not self.db.requests then
    self.db.requests = {}
  end
end

function SND:NormalizeRequestData(request)
  if type(request) ~= "table" then
    return nil
  end

  if self.NormalizeRecipeSpellID then
    request.recipeSpellID = self:NormalizeRecipeSpellID(request.recipeSpellID)
  else
    if type(request.recipeSpellID) == "table" then
      request.recipeSpellID = tonumber(request.recipeSpellID.recipeSpellID)
        or tonumber(request.recipeSpellID.selectedRecipeSpellID)
        or tonumber(request.recipeSpellID.spellID)
    elseif type(request.recipeSpellID) ~= "number" then
      request.recipeSpellID = tonumber(request.recipeSpellID)
    end
  end

  local normalizedQty = tonumber(request.qty)
  normalizedQty = normalizedQty and math.floor(normalizedQty) or 1
  if normalizedQty < 1 then
    normalizedQty = 1
  end
  request.qty = normalizedQty

  if type(request.notes) ~= "string" then
    request.notes = ""
  end

  if request.needsMats == nil then
    request.needsMats = false
  else
    request.needsMats = request.needsMats and true or false
  end

  if type(request.ownedCounts) ~= "table" then
    request.ownedCounts = {}
  end
  for itemID, value in pairs(request.ownedCounts) do
    local itemNum = tonumber(itemID)
    local countNum = tonumber(value)
    countNum = countNum and math.floor(countNum) or 0
    if not itemNum or countNum < 0 then
      request.ownedCounts[itemID] = nil
    else
      request.ownedCounts[itemNum] = countNum
      if itemNum ~= itemID then
        request.ownedCounts[itemID] = nil
      end
    end
  end

  local now = self:Now()
  applyRequestMeta(self, request, now)

  return request
end

function SND:CreateRequest(recipeSpellID, qty, notes, options)
  if self.NormalizeRecipeSpellID then
    recipeSpellID = self:NormalizeRecipeSpellID(recipeSpellID)
  else
    if type(recipeSpellID) == "table" then
      recipeSpellID = tonumber(recipeSpellID.recipeSpellID)
        or tonumber(recipeSpellID.selectedRecipeSpellID)
        or tonumber(recipeSpellID.spellID)
    elseif type(recipeSpellID) ~= "number" then
      recipeSpellID = tonumber(recipeSpellID)
    end
  end
  if not recipeSpellID then
    return nil
  end

  local requester = self:GetPlayerKey(UnitName("player"))
  local requestId = buildRequestId(UnitGUID("player"))
  local now = self:Now()
  local normalizedQty = tonumber(qty)
  normalizedQty = normalizedQty and math.floor(normalizedQty) or 1
  if normalizedQty < 1 then
    normalizedQty = 1
  end

  options = options or {}
  local needsMats = options.needsMats and true or false
  local ownedCounts = {}
  if type(options.ownedCounts) == "table" then
    for itemID, value in pairs(options.ownedCounts) do
      local itemNum = tonumber(itemID)
      local countNum = tonumber(value)
      countNum = countNum and math.floor(countNum) or 0
      if itemNum and countNum >= 0 then
        ownedCounts[itemNum] = countNum
      end
    end
  end

  local request = {
    id = requestId,
    entityType = "REQUEST",
    recipeSpellID = recipeSpellID,
    itemID = nil,
    qty = normalizedQty,
    notes = notes or "",
    needsMats = needsMats,
    ownedCounts = ownedCounts,
    requester = requester,
    claimedBy = nil,
    status = STATUS_OPEN,
    createdAt = now,
    updatedAt = now,
    updatedAtServer = now,
    updatedBy = requester,
    version = 1,
    deletedAtServer = nil,
    requesterMatsSnapshot = self:SnapshotMats(recipeSpellID, normalizedQty),
  }

  self:NormalizeRequestData(request)

  self.db.requests[requestId] = request
  self:SendRequestNew(requestId, request)
  return requestId
end

function SND:UpdateRequestStatus(requestId, newStatus, claimedBy)
  local request = self.db.requests[requestId]
  if not request then
    return
  end
  if not self:CanUpdateRequest(request, newStatus) then
    return
  end
  request.status = newStatus
  request.claimedBy = claimedBy
  request.version = (tonumber(request.version) or 1) + 1
  request.updatedAtServer = self:Now()
  request.updatedAt = request.updatedAtServer
  request.updatedBy = self:GetPlayerKey(UnitName("player"))
  self:SendRequestUpdate(requestId, request)
end

function SND:CancelRequest(requestId)
  self:UpdateRequestStatus(requestId, STATUS_CANCELLED)
end

function SND:IsGuildMaster(actorKey)
  local playerKey = actorKey or self:GetPlayerKey(UnitName("player"))
  local entry = self.db.players[playerKey]
  if not entry or entry.guildRankIndex == nil then
    return false
  end
  return entry.guildRankIndex == 0
end

function SND:ResolveRequestPolicyActorKey(actorKey)
  return actorKey or self:GetPlayerKey(UnitName("player"))
end

function SND:RequestPolicyCanManage(request, actorKey)
  if self:IsDebugModeEnabled() then
    return true
  end
  local playerKey = self:ResolveRequestPolicyActorKey(actorKey)
  local isRequester = request and request.requester == playerKey
  return isRequester or self:IsGuildMaster(playerKey)
end

function SND:RequestPolicyCanUpdate(request, newStatus, actorKey)
  local playerKey = self:ResolveRequestPolicyActorKey(actorKey)
  local isRequester = request.requester == playerKey
  local isClaimer = request.claimedBy == playerKey
  local isOfficer = self:IsOfficerOrAbove(playerKey)
  local canManage = self:RequestPolicyCanManage(request, playerKey)

  if newStatus == STATUS_CANCELLED then
    return canManage
  end
  if newStatus == STATUS_CLAIMED then
    return request.status == STATUS_OPEN
  end
  if newStatus == STATUS_OPEN then
    return isClaimer or isOfficer
  end
  if newStatus == STATUS_CRAFTED then
    return isClaimer or isRequester or isOfficer
  end
  if newStatus == STATUS_DELIVERED then
    return isClaimer or isRequester or isOfficer
  end
  return false
end

function SND:RequestPolicyAuthorizeInboundMutation(incomingRequest, existingRequest, actorKey)
  if type(incomingRequest) ~= "table" then
    return false, "invalid_request"
  end

  local policyActorKey = self:ResolveRequestPolicyActorKey(actorKey)
  local updatedBy = tostring(incomingRequest.updatedBy or "")
  if updatedBy == "" then
    return false, "updatedBy_missing"
  end
  if updatedBy ~= policyActorKey then
    return false, "updatedBy_mismatch"
  end

  local baseRequest = existingRequest or incomingRequest
  if self:RequestPolicyCanManage(baseRequest, policyActorKey) then
    return true
  end
  if self:RequestPolicyCanUpdate(baseRequest, incomingRequest.status, policyActorKey) then
    return true
  end

  return false, "insufficient_permissions"
end

function SND:RequestPolicyAuthorizeInboundDelete(existingRequest, tombstone, actorKey)
  if type(tombstone) ~= "table" then
    return false, "invalid_tombstone"
  end

  local policyActorKey = self:ResolveRequestPolicyActorKey(actorKey)
  local updatedBy = tostring(tombstone.updatedBy or "")
  if updatedBy == "" then
    return false, "updatedBy_missing"
  end
  if updatedBy ~= policyActorKey then
    return false, "updatedBy_mismatch"
  end

  if existingRequest and not self:RequestPolicyCanManage(existingRequest, policyActorKey) then
    return false, "insufficient_permissions"
  end

  return true
end

function SND:CanManageRequest(request, actorKey)
  return self:RequestPolicyCanManage(request, actorKey)
end

function SND:CanUpdateRequest(request, newStatus, actorKey)
  return self:RequestPolicyCanUpdate(request, newStatus, actorKey)
end

function SND:IsOfficerOrAbove(actorKey)
  local playerKey = actorKey or self:GetPlayerKey(UnitName("player"))
  local entry = self.db.players[playerKey]
  if not entry or entry.guildRankIndex == nil then
    return false
  end
  return entry.guildRankIndex <= (self.db.config.officerRankIndex or 1)
end

function SND:SnapshotMats(recipeSpellID, qty)
  local snapshot = {}
  local reagents = self:GetRecipeReagents(recipeSpellID)
  if not reagents then
    return snapshot
  end

  for itemID, count in pairs(reagents) do
    local required = count * qty
    local have = GetItemCount(itemID, true)
    snapshot[itemID] = have
  end
  return snapshot
end

function SND:GetRecipeReagents(recipeSpellID)
  if self.NormalizeRecipeSpellID then
    recipeSpellID = self:NormalizeRecipeSpellID(recipeSpellID)
  else
    if type(recipeSpellID) == "table" then
      recipeSpellID = tonumber(recipeSpellID.recipeSpellID)
        or tonumber(recipeSpellID.selectedRecipeSpellID)
        or tonumber(recipeSpellID.spellID)
    elseif type(recipeSpellID) ~= "number" then
      recipeSpellID = tonumber(recipeSpellID)
    end
  end

  if not recipeSpellID then
    return nil
  end

  local recipeEntry = self.db.recipeIndex[recipeSpellID]
  if recipeEntry and recipeEntry.reagents then
    return recipeEntry.reagents
  end
  if not C_TradeSkillUI or type(C_TradeSkillUI.GetRecipeSchematic) ~= "function" then
    return nil
  end

  local schematic = C_TradeSkillUI.GetRecipeSchematic(recipeSpellID, false)
  if not schematic or not schematic.reagentSlotSchematics then
    return nil
  end

  local reagents = {}
  for _, slot in ipairs(schematic.reagentSlotSchematics) do
    if slot.reagents then
      for _, reagent in ipairs(slot.reagents) do
        if reagent.itemID then
          reagents[reagent.itemID] = (reagents[reagent.itemID] or 0) + reagent.quantityRequired
        end
      end
    end
  end

  if recipeEntry then
    recipeEntry.reagents = reagents
    recipeEntry.lastUpdated = self:Now()
  end

  return reagents
end

function SND:SendRequestNew(requestId, request)
  local serialized = self.comms.serializer:Serialize({ id = requestId, data = request })
  local compressed = self.comms.deflate:CompressDeflate(serialized)
  local encoded = self.comms.deflate:EncodeForWoWAddonChannel(compressed)
  self:SendAddonMessage(string.format("REQ_NEW|%s", encoded))
end

function SND:SendRequestUpdate(requestId, request)
  local serialized = self.comms.serializer:Serialize({ id = requestId, data = request })
  local compressed = self.comms.deflate:CompressDeflate(serialized)
  local encoded = self.comms.deflate:EncodeForWoWAddonChannel(compressed)
  self:SendAddonMessage(string.format("REQ_UPD|%s", encoded))
end

function SND:SendRequestDelete(requestId)
  local tombstone = {
    id = requestId,
    entityType = "REQUEST",
    deletedAtServer = self:Now(),
    updatedAtServer = self:Now(),
    updatedBy = self:GetPlayerKey(UnitName("player")),
  }
  self.db.requestTombstones = self.db.requestTombstones or {}
  self.db.requestTombstones[requestId] = tombstone
  local serialized = self.comms.serializer:Serialize({ id = requestId, tombstone = tombstone })
  local compressed = self.comms.deflate:CompressDeflate(serialized)
  local encoded = self.comms.deflate:EncodeForWoWAddonChannel(compressed)
  self:SendAddonMessage(string.format("REQ_DEL|%s", encoded))
end

function SND:SendRequestFullState()
  self.db.requestTombstones = self.db.requestTombstones or {}
  local payload = {
    requests = self.db.requests,
    tombstones = self.db.requestTombstones,
    updatedAtServer = self:Now(),
    updatedBy = self:GetPlayerKey(UnitName("player")),
  }
  local serialized = self.comms.serializer:Serialize(payload)
  local compressed = self.comms.deflate:CompressDeflate(serialized)
  local encoded = self.comms.deflate:EncodeForWoWAddonChannel(compressed)
  self:SendAddonMessage(string.format("REQ_FULL|%s", encoded))
end
