local addonName = ...
local SND = _G[addonName]
local AceDB = LibStub("AceDB-3.0")

local DEFAULT_DB = {
  schemaVersion = 2,
  guildKey = nil,
  players = {},
  recipeIndex = {},
  requests = {},
  requestTombstones = {},
  config = {
    autoPublishOnLogin = true,
    autoPublishOnLearn = true,
    officerRankIndex = 1,
    showMinimapButton = false,
    minimapAngle = 220,
    minimapIconDB = {
      minimapPos = 220,
      hide = false,
    },
    debugMode = false,
    shareMatsExclusions = {},
  },
}

local ACE_DB_DEFAULTS = {
  profile = DEFAULT_DB,
}

local function shallowCopy(src)
  local dst = {}
  for key, value in pairs(src) do
    dst[key] = value
  end
  return dst
end

local function deepCopy(value)
  if type(value) ~= "table" then
    return value
  end
  local out = {}
  for k, v in pairs(value) do
    out[k] = deepCopy(v)
  end
  return out
end

local function isLegacyFlatDB(tbl)
  if type(tbl) ~= "table" then
    return false
  end
  if type(tbl.profile) == "table" then
    return false
  end
  return tbl.schemaVersion ~= nil
    or tbl.guildKey ~= nil
    or type(tbl.players) == "table"
    or type(tbl.recipeIndex) == "table"
    or type(tbl.requests) == "table"
    or type(tbl.config) == "table"
end

local function migrateLegacySavedVariables()
  local existing = _G.SomethingNeedDoingDB
  if not isLegacyFlatDB(existing) then
    return
  end
  _G.SomethingNeedDoingDB = {
    profileKeys = {},
    profiles = {
      Default = deepCopy(existing),
    },
  }
end

function SND:InitDB()
  migrateLegacySavedVariables()
  self.dbRoot = AceDB:New("SomethingNeedDoingDB", ACE_DB_DEFAULTS, true)
  self.db = self.dbRoot.profile
  self:EnsureDBDefaults()
end

function SND:ResetDB()
  if self.dbRoot and self.dbRoot.ResetProfile then
    self.dbRoot:ResetProfile()
    self.db = self.dbRoot.profile
  else
    _G.SomethingNeedDoingDB = shallowCopy(DEFAULT_DB)
    self.db = _G.SomethingNeedDoingDB
  end
  self:EnsureDBDefaults()
  if type(self.UpdateMinimapButtonVisibility) == "function" then
    self:UpdateMinimapButtonVisibility()
  end
  if type(self.RefreshOptions) == "function" then
    self:RefreshOptions()
  end
end

function SND:EnsureDBDefaults()
  local db = self.db
  if not db.schemaVersion then
    db.schemaVersion = DEFAULT_DB.schemaVersion
  end
  if not db.players then
    db.players = {}
  end
  if not db.recipeIndex then
    db.recipeIndex = {}
  end
  if not db.requests then
    db.requests = {}
  end
  if not db.requestTombstones then
    db.requestTombstones = {}
  end
  if not db.config then
    db.config = shallowCopy(DEFAULT_DB.config)
  else
    for key, value in pairs(DEFAULT_DB.config) do
      if db.config[key] == nil then
        db.config[key] = value
      end
    end
  end

  if db.config.showMinimapButton == nil then
    db.config.showMinimapButton = true
  end

  if db.config.minimapAngle == nil then
    db.config.minimapAngle = 220
  end

  if db.config.minimapIconDB == nil then
    db.config.minimapIconDB = {
      minimapPos = db.config.minimapAngle,
      hide = not (db.config.showMinimapButton and true or false),
    }
  else
    if db.config.minimapIconDB.minimapPos == nil then
      db.config.minimapIconDB.minimapPos = db.config.minimapAngle
    end
    if db.config.minimapIconDB.hide == nil then
      db.config.minimapIconDB.hide = not (db.config.showMinimapButton and true or false)
    end
  end

  if db.config.shareMatsOptIn == nil then
    db.config.shareMatsOptIn = false
  end

  if db.config.autoPublishMats == nil then
    db.config.autoPublishMats = true
  end

  if db.config.shareMatsExclusions == nil then
    db.config.shareMatsExclusions = {}
  end
end

function SND:SetGuildKey(guildName)
  if not guildName or guildName == "" then
    return
  end
  local faction = UnitFactionGroup("player") or "Neutral"
  local realm = GetRealmName() or "Unknown"
  self.db.guildKey = string.format("%s|%s|%s", realm, faction, guildName)
end

function SND:PurgeStaleData()
  local now = self:Now()
  local cutoffPlayers = now - (30 * 24 * 60 * 60)
  local cutoffRequests = now - (45 * 24 * 60 * 60)

  for playerKey, player in pairs(self.db.players) do
    if player.lastSeen and player.lastSeen < cutoffPlayers then
      self.db.players[playerKey] = nil
    end
  end

  for requestId, request in pairs(self.db.requests) do
    if request.updatedAt and request.updatedAt < cutoffRequests then
      if request.status ~= "OPEN" and request.status ~= "CLAIMED" then
        self.db.requests[requestId] = nil
      end
    end
  end

  for requestId, tombstone in pairs(self.db.requestTombstones) do
    local deletedAt = tombstone and tombstone.deletedAtServer
    if deletedAt and deletedAt < cutoffRequests then
      self.db.requestTombstones[requestId] = nil
    end
  end
end
